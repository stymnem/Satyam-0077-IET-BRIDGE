import React from "react";
import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./components/contexts/AuthContext";

import Login from "./components/Auth/Login";
import Register from "./components/Auth/Register";
import Navbar from "./components/Navbar";
import HomePage from "./components/HomePage";
import AboutPage from "./components/AboutPage";
import CoursesPage from "./components/CoursesPage";
import PlacementsPage from "./components/PlacementsPage";
import ContactPage from "./components/ContactPage";

import Profile from "./components/AlumniProfile/Profile";
import EducationList from "./components/Education/EducationList";
import EducationForm from "./components/Education/EducationForm";
import ExperienceList from "./components/ProfessionalExperience/ExperienceList";
import ExperienceForm from "./components/ProfessionalExperience/ExperienceForm";
import JobList from "./components/JobBoard/JobList";
import JobPost from "./components/JobBoard/JobPost";
import EventList from "./components/Events/EventList";
import EventForm from "./components/Events/EventForm";
import RSVPForm from "./components/Events/RSVPForm";
import AnnouncementList from "./components/Announcements/AnnouncementList";
import AnnouncementForm from "./components/Announcements/AnnouncementForm";
import Messages from "./components/Messaging/Messages";

import PrivateRoute from "./components/routes/PrivateRoute";
import RoleProtectedRoute from "./components/routes/RoleProtectedRoute";

// function Navigation() {
//   const { user, logout } = useAuth();
//   return (
//     <nav style={{ padding: 10, background: "#eee" }}>
//       {user ? (
//         <>
//           {user.role === "Alumni" && (
//             <>
//               <Link to="/profile">Profile</Link> |{" "}
//               <Link to="/education">Education</Link> |{" "}
//               <Link to="/professional-experience">Professional Experience</Link>{" "}
//               | <Link to="/jobs">Job Board</Link> |{" "}
//               <Link to="/events">Events</Link> |{" "}
//               <Link to="/announcements">Announcements</Link> |{" "}
//               <Link to="/messages">Messages</Link> |{" "}
//             </>
//           )}
//           {user.role === "Admin" && (
//             <>
//               <Link to="/events/manage">Manage Events</Link> |{" "}
//               <Link to="/announcements/manage">Manage Announcements</Link> |{" "}
//               <Link to="/rsvps/all">View All RSVPs</Link> |{" "}
//             </>
//           )}
//           <button onClick={logout}>Logout</button>
//         </>
//       ) : (
//         <Link to="/login">Login</Link>
//       )}
//     </nav>
//   );
// }

function App() {
  return (
    <AuthProvider>
      <>
        <Navbar />
        {/* <Navigation /> */}
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/courses" element={<CoursesPage />} />
          <Route path="/placements" element={<PlacementsPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Alumni routes */}
          <Route
            path="/profile"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <Profile />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/education"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <EducationList />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/education/new"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <EducationForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/education/edit/:id"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <EducationForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/professional-experience"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <ExperienceList />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/professional-experience/new"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <ExperienceForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/professional-experience/edit/:id"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <ExperienceForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/jobs"
            element={
              <PrivateRoute>
                <JobList />
              </PrivateRoute>
            }
          />
          <Route
            path="/jobs/post"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <JobPost />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/events"
            element={
              <PrivateRoute>
                <EventList />
              </PrivateRoute>
            }
          />
          <Route
            path="/events/manage"
            element={
              <RoleProtectedRoute allowedRoles={["Admin"]}>
                <EventForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/events/create"
            element={
              <RoleProtectedRoute allowedRoles={["Admin"]}>
                <EventForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/events/rsvp"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <RSVPForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/announcements"
            element={
              <PrivateRoute>
                <AnnouncementList />
              </PrivateRoute>
            }
          />
          <Route
            path="/announcements/manage"
            element={
              <RoleProtectedRoute allowedRoles={["Admin"]}>
                <AnnouncementForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/announcements/create"
            element={
              <RoleProtectedRoute allowedRoles={["Admin"]}>
                <AnnouncementForm />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/messages"
            element={
              <RoleProtectedRoute allowedRoles={["Alumni"]}>
                <Messages />
              </RoleProtectedRoute>
            }
          />

          {/* Catch all */}
          <Route path="*" element={<Login />} />
        </Routes>
      </>
    </AuthProvider>
  );
}

export default App;
