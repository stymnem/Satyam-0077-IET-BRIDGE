import React from "react";

export default function AlumniDashboard() {
  return <h1>Welcome Alumni - View Events, Jobs, and Messages</h1>;
}
