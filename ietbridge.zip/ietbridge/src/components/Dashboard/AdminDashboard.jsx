import React from "react";

export default function AdminDashboard() {
  return <h1>Welcome Admin - Manage Events, Announcements and Users</h1>;
}
