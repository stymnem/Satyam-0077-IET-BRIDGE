import React, { useState } from "react";

export default function ContactPage() {
  // Simple form state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can add real submission logic here
    setSubmitted(true);
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#F1FAEE",
        color: "#333333",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Header */}
      <header
        style={{
          backgroundColor: "#1D3557",
          color: "#F1FAEE",
          padding: "40px 20px",
          textAlign: "center",
        }}
      >
        <h1 style={{ margin: 0, fontWeight: "700", fontSize: "2.5rem" }}>
          Contact Us
        </h1>
        <p style={{ marginTop: 10, fontSize: "1.15rem", color: "#A8DADC" }}>
          We’re here to help you at IETBRIDGE — Get in touch with our team
        </p>
      </header>

      {/* Body */}
      <main
        style={{
          flex: 1,
          maxWidth: 900,
          margin: "40px auto",
          padding: "0 20px",
          display: "flex",
          flexDirection: "row",
          gap: "60px",
          flexWrap: "wrap",
          justifyContent: "center",
        }}
      >
        {/* Contact Form */}
        <section
          style={{
            flex: "1 1 380px",
            backgroundColor: "#FFF",
            borderRadius: 12,
            padding: "30px 25px",
            boxShadow: "0 8px 24px rgb(29 53 87 / 0.12)",
          }}
          aria-label="Contact form"
        >
          <h2 style={{ color: "#1D3557", marginBottom: 20, fontWeight: 700 }}>
            Send a Message
          </h2>

          {submitted ? (
            <div
              role="alert"
              style={{
                backgroundColor: "#A8DADC",
                color: "#1D3557",
                padding: "18px 15px",
                borderRadius: 8,
                fontWeight: 600,
                fontSize: "1.1rem",
                textAlign: "center",
              }}
            >
              Thank you for reaching out! We will get back to you soon.
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <label
                htmlFor="name"
                style={{ display: "block", marginBottom: 6, fontWeight: 600 }}
              >
                Name
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                value={formData.name}
                onChange={handleChange}
                placeholder="Your full name"
                style={{
                  width: "100%",
                  padding: "10px 12px",
                  marginBottom: 20,
                  borderRadius: 6,
                  border: "1.8px solid #457B9D",
                  fontSize: "1rem",
                }}
              />

              <label
                htmlFor="email"
                style={{ display: "block", marginBottom: 6, fontWeight: 600 }}
              >
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                style={{
                  width: "100%",
                  padding: "10px 12px",
                  marginBottom: 20,
                  borderRadius: 6,
                  border: "1.8px solid #457B9D",
                  fontSize: "1rem",
                }}
              />

              <label
                htmlFor="message"
                style={{ display: "block", marginBottom: 6, fontWeight: 600 }}
              >
                Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                required
                value={formData.message}
                onChange={handleChange}
                placeholder="Write your message here"
                style={{
                  width: "100%",
                  padding: "10px 12px",
                  borderRadius: 6,
                  border: "1.8px solid #457B9D",
                  fontSize: "1rem",
                  resize: "vertical",
                }}
              />

              <button
                type="submit"
                style={{
                  backgroundColor: "#E63946",
                  color: "#F1FAEE",
                  padding: "12px 32px",
                  border: "none",
                  borderRadius: 8,
                  fontWeight: 700,
                  fontSize: "1.1rem",
                  cursor: "pointer",
                  transition: "background-color 0.3s ease",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.backgroundColor = "#d02e3c")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.backgroundColor = "#E63946")
                }
                aria-label="Send message"
              >
                Send Message
              </button>
            </form>
          )}
        </section>

        {/* Contact Info */}
        <aside
          style={{
            flex: "1 1 300px",
            backgroundColor: "#FFEFEF",
            borderRadius: 12,
            padding: "30px 25px",
            boxShadow: "0 8px 24px rgb(229 57 70 / 0.18)",
            color: "#1D3557",
          }}
          aria-label="Contact information"
        >
          <h2 style={{ marginBottom: 20, fontWeight: 700 }}>
            Contact Information
          </h2>
          <p style={{ fontWeight: 600, marginBottom: 10 }}>
            <strong>Email:</strong>{" "}
            <a
              href="mailto:info@ietbridge.in"
              style={{ color: "#457B9D", textDecoration: "underline" }}
            >
              info@ietbridge.in
            </a>
          </p>
          <p style={{ fontWeight: 600, marginBottom: 10 }}>
            <strong>Phone:</strong> +91-20-12345678
          </p>
          <p style={{ fontWeight: 600, marginBottom: 10 }}>
            <strong>Address:</strong> Institute of Emerging Technologies, Pune,
            India
          </p>
          <p style={{ marginTop: 30 }}>
            <em>Office hours:</em> Mon - Fri, 10:00 AM - 5:00 PM IST
          </p>
        </aside>
      </main>

      {/* Footer */}
      <footer
        style={{
          backgroundColor: "#1D3557",
          color: "#F1FAEE",
          textAlign: "center",
          padding: "18px 15px",
          fontSize: "0.95rem",
          fontWeight: "500",
          marginTop: "auto",
          userSelect: "none",
        }}
        aria-label="Footer"
      >
        &copy; {new Date().getFullYear()} IETBRIDGE | Institute of Emerging
        Technologies, Pune | C-DAC ACTS Authorized Training Centre
      </footer>
    </div>
  );
}
