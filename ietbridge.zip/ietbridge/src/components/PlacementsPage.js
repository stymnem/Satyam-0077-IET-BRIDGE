import React from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { Fade, Slide } from "react-awesome-reveal";

export default function PlacementsPage() {
  // Example placement highlights or stats
  const placementStats = [
    {
      title: "100% Placement Assistance",
      description:
        "We provide dedicated placement training and interview preparation to ensure every student is job-ready.",
      icon: "🎯",
    },
    {
      title: "Top IT Companies",
      description:
        "Our alumni have been recruited by leading companies like TCS, Infosys, Wipro, Cognizant, and more.",
      icon: "🏢",
    },
    {
      title: "Average Package ₹6 LPA",
      description:
        "Competitive salary packages offered to our graduates, reflecting high industry relevance of our courses.",
      icon: "💰",
    },
    {
      title: "Real-World Projects",
      description:
        "Hands-on projects and internships ensure practical knowledge and experience.",
      icon: "🛠️",
    },
    {
      title: "Soft Skills Training",
      description:
        "Aptitude, communication, and personality development sessions to boost confidence.",
      icon: "🗣️",
    },
    {
      title: "Strong Alumni Network",
      description:
        "Access to a growing network of professionals and mentors in the IT industry.",
      icon: "🤝",
    },
  ];

  return (
    <Container
      style={{
        padding: "60px 20px",
        maxWidth: "1000px",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      }}
    >
      {/* Title */}
      <Slide direction="down" triggerOnce>
        <h1
          style={{
            color: "#003366",
            marginBottom: "30px",
            fontWeight: "700",
            textAlign: "center",
          }}
        >
          Placements at IET Pune
        </h1>
      </Slide>

      {/* Intro paragraph */}
      <Fade cascade damping={0.2} triggerOnce>
        <p
          style={{
            fontSize: "1.15rem",
            color: "#333",
            textAlign: "center",
            marginBottom: "50px",
          }}
        >
          At IET Pune, our placement cell works rigorously to bridge the gap
          between talent and industry. We focus on holistic development,
          preparing you not just with technical skills, but also with soft
          skills and interview mastery for a successful career.
        </p>
      </Fade>

      {/* Placement stat cards */}
      <Row xs={1} md={2} className="g-4">
        {placementStats.map((stat, idx) => (
          <Col key={idx}>
            <Fade direction="up" delay={idx * 100} triggerOnce>
              <Card
                className="h-100 shadow-sm"
                style={{
                  borderRadius: "12px",
                  transition: "transform 0.3s ease",
                  cursor: "default",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-10px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <Card.Body>
                  <div
                    style={{
                      fontSize: "3rem",
                      textAlign: "center",
                      marginBottom: "15px",
                      userSelect: "none",
                    }}
                    aria-hidden="true"
                  >
                    {stat.icon}
                  </div>
                  <Card.Title
                    style={{
                      color: "#003366",
                      fontWeight: "700",
                      fontSize: "1.3rem",
                      textAlign: "center",
                      marginBottom: "12px",
                    }}
                  >
                    {stat.title}
                  </Card.Title>
                  <Card.Text
                    style={{
                      color: "#555",
                      fontSize: "1rem",
                      textAlign: "center",
                    }}
                  >
                    {stat.description}
                  </Card.Text>
                </Card.Body>
              </Card>
            </Fade>
          </Col>
        ))}
      </Row>

      {/* Call to action */}
      <Row className="mt-5 justify-content-center">
        <Col xs="auto">
          <Slide direction="up" triggerOnce>
            <Button
              href="https://ietpune.com/" // Official placement info redirect or your preferred link
              target="_blank"
              rel="noopener noreferrer"
              size="lg"
              style={{
                backgroundColor: "#003366",
                borderColor: "#003366",
                fontWeight: "700",
                padding: "12px 40px",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = "#002244";
                e.currentTarget.style.borderColor = "#002244";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = "#003366";
                e.currentTarget.style.borderColor = "#003366";
              }}
            >
              Explore Placement Opportunities
            </Button>
          </Slide>
        </Col>
      </Row>
    </Container>
  );
}
