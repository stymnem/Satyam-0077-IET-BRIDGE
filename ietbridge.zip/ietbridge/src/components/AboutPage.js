import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import { Fade, Slide } from "react-awesome-reveal";

export default function AboutPage() {
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F3F4F6",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Container
        style={{
          flex: 1,
          paddingTop: 64,
          paddingBottom: 30,
          fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
          color: "#232946",
        }}
      >
        {/* Title & Welcome */}
        <Fade cascade triggerOnce>
          <h1
            style={{
              fontWeight: 900,
              fontSize: "2.2rem",
              color: "#4B5171",
              marginBottom: 10,
              letterSpacing: ".5px",
            }}
          >
            About Institute of Emerging Technologies, Pune
          </h1>
          <p
            style={{
              color: "#232946",
              fontSize: "1.13rem",
              marginBottom: 32,
              lineHeight: 1.7,
              maxWidth: 740,
            }}
          >
            Founded in 2001, IET Pune is a place where{" "}
            <span style={{ color: "#9E2A2B", fontWeight: 700 }}>
              ambition meets expertise
            </span>
            . Our community welcomes every learner: new graduates,
            professionals, dreamers, and doers. We believe great tech careers
            begin in a culture that values real growth, practical wisdom, and
            lasting connections.
          </p>
        </Fade>

        {/* Key Values Section */}
        <Row className="align-items-stretch" style={{ marginBottom: 36 }}>
          <Col md={4}>
            <Card
              style={{
                background: "#FFFFFF",
                borderRadius: 14,
                border: "none",
                boxShadow: "0 2px 12px #23294614",
                marginBottom: 18,
              }}
            >
              <Card.Body>
                <h3
                  style={{
                    color: "#9E2A2B",
                    fontWeight: 800,
                    fontSize: "1.13rem",
                  }}
                >
                  Guided by Experience
                </h3>
                <p style={{ color: "#232946", fontSize: "1rem" }}>
                  Learn from accomplished professionals and faculty who care
                  about where you are heading, not just what you score.
                </p>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card
              style={{
                background: "#F9F8F5",
                borderRadius: 14,
                border: "none",
                boxShadow: "0 2px 10px #23294611",
                marginBottom: 18,
              }}
            >
              <Card.Body>
                <h3
                  style={{
                    color: "#CBA135",
                    fontWeight: 800,
                    fontSize: "1.13rem",
                  }}
                >
                  Whole-Person Growth
                </h3>
                <p style={{ color: "#232946", fontSize: "1rem" }}>
                  Aptitude, communication, and self-confidence are as important
                  as code—our mentors help you grow in all dimensions.
                </p>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card
              style={{
                background: "#FFFFFF",
                borderRadius: 14,
                border: "none",
                boxShadow: "0 2px 12px #23294614",
                marginBottom: 18,
              }}
            >
              <Card.Body>
                <h3
                  style={{
                    color: "#4B5171",
                    fontWeight: 800,
                    fontSize: "1.13rem",
                  }}
                >
                  Community & Opportunity
                </h3>
                <p style={{ color: "#232946", fontSize: "1rem" }}>
                  Our alumni work in leading firms worldwide and unite for
                  learning, giving back, and building lasting friendships.
                </p>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Campus & Life Section */}
        <Fade cascade triggerOnce>
          <h2
            style={{
              fontWeight: 700,
              fontSize: "1.28rem",
              color: "#4B5171",
              marginBottom: 8,
              letterSpacing: ".1px",
            }}
          >
            Inside IET: What You’ll Find
          </h2>
          <ul
            style={{
              color: "#232946",
              fontSize: "1.06rem",
              fontWeight: 500,
              paddingLeft: 20,
              marginBottom: 24,
            }}
          >
            <li>Project-based learning, not just theory</li>
            <li>Open labs & honest mentorship</li>
            <li>Coding marathons, club life, and collaborative events</li>
            <li style={{ color: "#9E2A2B" }}>
              No barriers for career switchers or those new to tech
            </li>
          </ul>
          <div
            style={{
              background: "#F4F5F7",
              borderLeft: "5px solid #CBA135",
              borderRadius: 8,
              padding: "18px 22px",
              color: "#4B5171",
              fontWeight: 600,
              marginBottom: 30,
              fontSize: "1.03rem",
            }}
          >
            Whatever your journey so far, your learning story is respected and
            supported here.
          </div>
        </Fade>

        {/* Call to Action Section */}
        <Slide direction="up" triggerOnce>
          <div
            style={{
              textAlign: "center",
              margin: "48px 0 28px 0",
              fontWeight: 700,
              color: "#9E2A2B",
              fontSize: "1.15rem",
            }}
          >
            <span style={{ fontSize: "1.5rem", verticalAlign: "middle" }}>
              👋
            </span>
            Curious?{" "}
            <span style={{ color: "#CBA135" }}>
              We welcome all learners—from any field, at any stage.
            </span>
            <br />
            <a
              href="https://ietpune.com/"
              style={{
                marginTop: 12,
                display: "inline-block",
                background: "#232946",
                color: "#F4F5F7",
                padding: "12px 38px",
                borderRadius: "6px",
                fontWeight: 700,
                fontSize: "1.1rem",
                textDecoration: "none",
                letterSpacing: 1,
                boxShadow: "0 2px 12px #4b517144",
                transition: "background 0.17s",
              }}
              onMouseOver={(e) =>
                (e.currentTarget.style.background = "#9E2A2B")
              }
              onMouseOut={(e) => (e.currentTarget.style.background = "#232946")}
              aria-label="Go to IET Pune website for admission"
            >
              Join IET Pune Today
            </a>
          </div>
        </Slide>

        {/* Closing tagline as requested */}
        <div
          style={{
            marginTop: "30px",
            textAlign: "center",
            color: "#232946",
            fontWeight: "600",
            fontSize: "1.16rem",
            lineHeight: 1.43,
            letterSpacing: ".02rem",
            userSelect: "none",
          }}
        >
          This isn’t your parent’s computer institute.
          <br />
          <span style={{ color: "#CBA135" }}>
            At IET Pune, the future gets personal—and fun!
          </span>
        </div>
      </Container>

      {/* Mature footer */}
      <footer
        style={{
          background: "#232946",
          color: "#F4F5F7",
          textAlign: "center",
          padding: "20px 10px 10px 10px",
          fontSize: "0.98rem",
          fontWeight: "500",
          letterSpacing: ".02em",
          marginTop: "auto",
        }}
      >
        &copy; {new Date().getFullYear()} Institute of Emerging Technologies,
        Pune | C-DAC ACTS Authorized Training Centre |{" "}
        <a
          href="mailto:info@ietpune.in"
          style={{ color: "#CBA135", textDecoration: "underline" }}
        >
          info@ietpune.in
        </a>{" "}
        | Phone: +91-20-12345678
      </footer>
    </div>
  );
}
