import React from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { Fade, Slide } from "react-awesome-reveal";

export default function HomePage() {
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F3F4F6",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Container
        style={{
          flex: 1,
          paddingTop: 64,
          paddingBottom: 30,
          fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
          color: "#232946",
        }}
      >
        {/* Title & Welcome */}
        <Fade cascade triggerOnce>
          <h1
            style={{
              fontWeight: 900,
              fontSize: "2.2rem",
              color: "#4B5171",
              marginBottom: 8,
              letterSpacing: ".5px",
            }}
          >
            IETBRIDGE – Alumni Management System
          </h1>
          <p
            style={{
              color: "#232946",
              fontSize: "1.17rem",
              marginBottom: 32,
              lineHeight: 1.68,
              maxWidth: 720,
            }}
          >
            Welcome to{" "}
            <span style={{ color: "#9E2A2B", fontWeight: 700 }}>IETBRIDGE</span>
            , the official alumni platform of Institute of Emerging
            Technologies, Pune.
            <br />
            <span style={{ color: "#CBA135" }}>
              Stay connected. Grow your career. Give back.
              <br />
              Become part of a thriving global IET community.
            </span>
          </p>
        </Fade>

        {/* Who can use section */}
        <Row className="align-items-stretch" style={{ marginBottom: 40 }}>
          <Col md={6} style={{ marginBottom: 22 }}>
            <Card
              style={{
                background: "#FFFFFF",
                borderRadius: 13,
                border: "none",
                boxShadow: "0 2px 10px #23294612",
              }}
            >
              <Card.Body>
                <h3
                  style={{
                    color: "#4B5171",
                    fontWeight: 800,
                    fontSize: "1.09rem",
                  }}
                >
                  For Recent Graduates
                </h3>
                <p style={{ color: "#232946", fontSize: "0.99rem" }}>
                  Secure your network and opportunities from day one—connect
                  with experienced alumni, mentors, and IET placement teams.
                </p>
                <Button
                  href="/register"
                  variant="outline-primary"
                  style={{
                    borderColor: "#9E2A2B",
                    color: "#9E2A2B",
                    fontWeight: 700,
                    marginTop: 10,
                  }}
                >
                  Register as New Alumni
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={6} style={{ marginBottom: 22 }}>
            <Card
              style={{
                background: "#FAFAFA",
                borderRadius: 13,
                border: "none",
                boxShadow: "0 2px 10px #23294614",
              }}
            >
              <Card.Body>
                <h3
                  style={{
                    color: "#CBA135",
                    fontWeight: 800,
                    fontSize: "1.09rem",
                  }}
                >
                  For Existing Alumni
                </h3>
                <p style={{ color: "#232946", fontSize: "0.99rem" }}>
                  Log in to maintain your profile, share job leads, post events,
                  and inspire the next batch of tech leaders.
                </p>
                <Button
                  href="/login"
                  variant="outline-secondary"
                  style={{
                    borderColor: "#4B5171",
                    color: "#4B5171",
                    fontWeight: 700,
                    marginTop: 10,
                  }}
                >
                  Alumni Login
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Use-cases highlight */}
        <Fade direction="up" triggerOnce>
          <h2
            style={{
              fontWeight: 700,
              fontSize: "1.24rem",
              color: "#4B5171",
              marginBottom: 18,
            }}
          >
            What You Can Do with IETBRIDGE
          </h2>
          <ul
            style={{
              color: "#232946",
              fontSize: "1.03rem",
              fontWeight: 500,
              paddingLeft: 24,
              marginBottom: 24,
            }}
          >
            <li>Find and connect with fellow IET alumni worldwide</li>
            <li>Update your education, experience, and career info</li>
            <li>Post or discover job openings and mentorship opportunities</li>
            <li>Join alumni events and reunions</li>
            <li>
              Grow your professional network and give back to the new students
            </li>
          </ul>
        </Fade>

        {/* Invitation and values */}
        <Slide direction="up" triggerOnce>
          <div
            style={{
              background: "#F9F8F5",
              borderLeft: "6px solid #CBA135",
              borderRadius: 8,
              padding: "20px 24px",
              color: "#4B5171",
              fontWeight: 600,
              margin: "36px 0 22px 0",
              fontSize: "1.04rem",
              boxShadow: "0 2px 10px #2329460A",
            }}
          >
            At IET Pune, the alumni network is your lifelong advantage:
            unlocking jobs, new skills, and deep friendships.
            <br />
            <span style={{ color: "#9E2A2B", fontWeight: 800 }}>
              Start your journey — or rekindle it — with people who believe in
              you.
            </span>
          </div>
        </Slide>

        {/* Closing tagline as requested */}
        <div
          style={{
            textAlign: "center",
            color: "#232946",
            fontWeight: "600",
            fontSize: "1.15rem",
            lineHeight: 1.4,
            marginTop: 34,
            letterSpacing: ".01em",
          }}
        >
          This isn’t your parent’s computer institute.
          <br />
          <span style={{ color: "#CBA135" }}>
            At IET Pune, the future gets personal—and fun!
          </span>
        </div>
      </Container>

      {/* Elegant footer */}
      <footer
        style={{
          background: "#232946",
          color: "#F4F5F7",
          textAlign: "center",
          padding: "22px 10px 12px 10px",
          fontSize: "0.98rem",
          fontWeight: "500",
          letterSpacing: ".01em",
          marginTop: "auto",
        }}
      >
        &copy; {new Date().getFullYear()} IETBRIDGE | Institute of Emerging
        Technologies, Pune |{" "}
        <a
          href="mailto:info@ietpune.in"
          style={{ color: "#CBA135", textDecoration: "underline" }}
        >
          info@ietpune.in
        </a>{" "}
        | Phone: +91-20-12345678
      </footer>
    </div>
  );
}
