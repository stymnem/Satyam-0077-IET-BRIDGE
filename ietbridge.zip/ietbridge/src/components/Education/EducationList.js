import React, { useEffect, useState } from "react";
import api from "../../services/api";
import { Link } from "react-router-dom";

export default function EducationList() {
  const [educations, setEducations] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/education")
      .then((res) => setEducations(res.data))
      .catch(() => setError("Failed to load education records"));
  }, []);

  return (
    <div>
      <h2>Education Records</h2>
      <Link
        to="/education/new"
        style={{ marginBottom: 10, display: "inline-block" }}
      >
        Add New Education
      </Link>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <ul>
        {educations.map((ed) => (
          <li key={ed.id}>
            {ed.degree} in {ed.branch} from {ed.institute} ({ed.graduationYear}){" "}
            <Link to={`/education/edit/${ed.id}`}>Edit</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
