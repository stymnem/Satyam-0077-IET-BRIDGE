import React, { useState, useEffect } from "react";
import api from "../../services/api"; // Axios instance with JWT interceptor
import { useNavigate, useParams } from "react-router-dom";

export default function EducationForm() {
  const [form, setForm] = useState({
    degree: "",
    branch: "",
    institute: "",
    graduationYear: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { id } = useParams(); // id is used for editing an existing entry

  // Fetch existing data for edit
  useEffect(() => {
    if (id) {
      api
        .get(`/education/${id}`)
        .then((res) => {
          setForm({
            degree: res.data.degree || "",
            branch: res.data.branch || "",
            institute: res.data.institute || "",
            graduationYear: res.data.graduationYear?.toString() || "",
          });
        })
        .catch((err) => {
          if (err.response && err.response.status === 404) {
            setError("Education record not found!");
            // Optionally redirect or reset form for creation
          } else {
            setError("Failed to load education record");
          }
        });
    }
  }, [id]);

  // Handle input changes
  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    // Basic validation
    if (
      !form.degree.trim() ||
      !form.branch.trim() ||
      !form.institute.trim() ||
      !form.graduationYear.trim()
    ) {
      setError("All fields are required.");
      return;
    }

    const graduationYearInt = parseInt(form.graduationYear, 10);

    if (
      isNaN(graduationYearInt) ||
      graduationYearInt < 1900 ||
      graduationYearInt > 2100
    ) {
      setError("Please enter a valid graduation year between 1900 and 2100.");
      return;
    }

    const payload = {
      id: id ? parseInt(id, 10) : 0, // 0 for POST; actual id for PUT
      degree: form.degree.trim(),
      branch: form.branch.trim(),
      institute: form.institute.trim(),
      graduationYear: graduationYearInt,
    };

    try {
      if (id) {
        // Editing existing education
        await api.put(`/education/${id}`, payload);
      } else {
        // Creating new education
        await api.post("/education", payload);
      }

      // Redirect back to education list or any other page
      navigate("/education");
    } catch (err) {
      if (err.response && err.response.data) {
        setError(
          `Failed to save: ${
            err.response.data.message || JSON.stringify(err.response.data)
          }`
        );
      } else {
        setError("Failed to save education record.");
      }
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto", paddingTop: 20 }}>
      <h2>{id ? "Edit" : "Add"} Education</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 12 }}>
          <label htmlFor="degree">Degree</label>
          <br />
          <input
            id="degree"
            name="degree"
            type="text"
            value={form.degree}
            onChange={handleChange}
            required
            style={{ width: "100%", padding: 8 }}
            placeholder="e.g., Bachelor of Science"
          />
        </div>

        <div style={{ marginBottom: 12 }}>
          <label htmlFor="branch">Branch</label>
          <br />
          <input
            id="branch"
            name="branch"
            type="text"
            value={form.branch}
            onChange={handleChange}
            required
            style={{ width: "100%", padding: 8 }}
            placeholder="e.g., Computer Science"
          />
        </div>

        <div style={{ marginBottom: 12 }}>
          <label htmlFor="institute">Institute</label>
          <br />
          <input
            id="institute"
            name="institute"
            type="text"
            value={form.institute}
            onChange={handleChange}
            required
            style={{ width: "100%", padding: 8 }}
            placeholder="e.g., Example University"
          />
        </div>

        <div style={{ marginBottom: 12 }}>
          <label htmlFor="graduationYear">Graduation Year</label>
          <br />
          <input
            id="graduationYear"
            name="graduationYear"
            type="number"
            min="1900"
            max="2100"
            value={form.graduationYear}
            onChange={handleChange}
            required
            style={{ width: "100%", padding: 8 }}
            placeholder="e.g., 2025"
          />
        </div>

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit" style={{ padding: "10px 16px" }}>
          {id ? "Update" : "Add"} Education
        </button>
      </form>
    </div>
  );
}
