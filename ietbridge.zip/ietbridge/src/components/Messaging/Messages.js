import React, { useState, useEffect } from "react";
import api from "../../services/api";

export default function Messages() {
  const [tab, setTab] = useState("inbox");
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ receiverEmail: "", content: "" });
  const [sendSuccess, setSendSuccess] = useState("");

  useEffect(() => {
    fetchMessages();
  }, [tab]);

  const fetchMessages = async () => {
    setError("");
    try {
      const endpoint = tab === "inbox" ? "/messages/inbox" : "/messages/sent";
      const res = await api.get(endpoint);
      setMessages(res.data);
    } catch {
      setError("Failed to load messages");
    }
  };

  const handleInputChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSend = async (e) => {
    e.preventDefault();
    setError("");
    setSendSuccess("");
    if (!form.receiverEmail || !form.content) {
      setError("Please fill all fields");
      return;
    }
    try {
      await api.post("/messages", form);
      setForm({ receiverEmail: "", content: "" });
      setSendSuccess("Message sent successfully");
      if (tab === "sent") fetchMessages();
    } catch {
      setError("Failed to send message");
    }
  };

  return (
    <div style={{ maxWidth: 700, margin: "auto", padding: 20 }}>
      <h2>Messages</h2>

      <div style={{ marginBottom: 15 }}>
        <button onClick={() => setTab("inbox")} disabled={tab === "inbox"}>
          Inbox
        </button>
        <button
          onClick={() => setTab("sent")}
          disabled={tab === "sent"}
          style={{ marginLeft: 8 }}
        >
          Sent
        </button>
      </div>

      {error && <p style={{ color: "red" }}>{error}</p>}

      <table
        border="1"
        cellPadding="8"
        cellSpacing="0"
        style={{ width: "100%", marginBottom: 20 }}
      >
        <thead>
          <tr>
            <th>{tab === "inbox" ? "Sender" : "Receiver"}</th>
            <th>Message</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {messages.length === 0 && (
            <tr>
              <td colSpan="4" style={{ textAlign: "center" }}>
                No messages
              </td>
            </tr>
          )}
          {messages.map((m) => (
            <tr
              key={m.id}
              style={{
                fontWeight: tab === "inbox" && !m.seen ? "bold" : "normal",
              }}
            >
              <td>{tab === "inbox" ? m.senderEmail : m.receiverEmail}</td>
              <td>{m.content}</td>
              <td>{new Date(m.sentAt || m.createdAt).toLocaleString()}</td>
              <td>{tab === "inbox" ? (m.seen ? "Read" : "Unread") : "Sent"}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Send a Message</h3>
      <form onSubmit={handleSend}>
        <input
          type="email"
          name="receiverEmail"
          value={form.receiverEmail}
          onChange={handleInputChange}
          placeholder="Receiver's email"
          required
          style={{ width: "100%", marginBottom: 10, padding: 8 }}
        />
        <textarea
          name="content"
          value={form.content}
          onChange={handleInputChange}
          placeholder="Write your message here..."
          required
          style={{ width: "100%", marginBottom: 10, padding: 8, height: 120 }}
        />
        <button type="submit">Send</button>
      </form>
      {sendSuccess && <p style={{ color: "green" }}>{sendSuccess}</p>}
    </div>
  );
}
