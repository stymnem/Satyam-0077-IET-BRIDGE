import React, { useEffect, useState } from "react";
import api from "../../services/api";
import { Link } from "react-router-dom";

export default function JobList() {
  const [jobs, setJobs] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/jobpostings")
      .then((res) => setJobs(res.data))
      .catch(() => setError("Failed to load job postings"));
  }, []);

  return (
    <div>
      <h2>Job Listings</h2>
      <Link
        to="/jobs/post"
        style={{ marginBottom: 10, display: "inline-block" }}
      >
        Post a Job (Alumni only)
      </Link>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <ul>
        {jobs.map((job) => (
          <li key={job.id}>
            <strong>{job.title}</strong> at {job.company} - {job.industry}
          </li>
        ))}
      </ul>
    </div>
  );
}
