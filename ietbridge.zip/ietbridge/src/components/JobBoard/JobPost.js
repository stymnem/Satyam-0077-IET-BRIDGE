import React, { useState } from "react";
import api from "../../services/api";
import { useNavigate } from "react-router-dom";

export default function JobPost() {
  const [form, setForm] = useState({
    title: "",
    company: "",
    industry: "",
    description: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/jobpostings", form);
      navigate("/jobs");
    } catch {
      setError("Failed to post job");
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto" }}>
      <h2>Post a New Job</h2>
      <form onSubmit={handleSubmit}>
        <label>Job Title</label>
        <br />
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Company</label>
        <br />
        <input
          name="company"
          value={form.company}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Industry</label>
        <br />
        <input
          name="industry"
          value={form.industry}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Description</label>
        <br />
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit">Post Job</button>
      </form>
    </div>
  );
}
