import React, { useEffect, useState } from "react";
import api from "../../services/api";

export default function RSVPForm() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    api
      .get("/events")
      .then((res) => setEvents(res.data))
      .catch(() => setError("Failed to load events"));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    if (!selectedEvent) {
      setError("Please select an event");
      return;
    }
    try {
      await api.post("/rsvps", { eventId: parseInt(selectedEvent) });
      setMessage("RSVP submitted successfully!");
    } catch {
      setError("Failed to submit RSVP");
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto" }}>
      <h2>RSVP to Event</h2>

      {error && <p style={{ color: "red" }}>{error}</p>}
      {message && <p style={{ color: "green" }}>{message}</p>}

      <form onSubmit={handleSubmit}>
        <select
          value={selectedEvent}
          onChange={(e) => setSelectedEvent(e.target.value)}
          required
          style={{ width: "100%", marginBottom: 10 }}
        >
          <option value="">-- Select Event --</option>
          {events.map((ev) => (
            <option key={ev.id} value={ev.id}>
              {ev.title}
            </option>
          ))}
        </select>

        <button type="submit">Submit RSVP</button>
      </form>
    </div>
  );
}
