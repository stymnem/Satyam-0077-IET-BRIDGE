import React, { useState, useEffect } from "react";
import api from "../../services/api";
import { useNavigate, useParams } from "react-router-dom";

export default function EventForm() {
  const [form, setForm] = useState({
    title: "",
    description: "",
    date: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      api
        .get(`/events/${id}`)
        .then((res) =>
          setForm({
            title: res.data.title || "",
            description: res.data.description || "",
            date: res.data.date?.substring(0, 10) || "",
          })
        )
        .catch(() => setError("Failed to load event"));
    }
  }, [id]);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      if (id) {
        await api.put(`/events/${id}`, form);
      } else {
        await api.post("/events", form);
      }
      navigate("/events/manage");
    } catch {
      setError("Failed to save event");
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto" }}>
      <h2>{id ? "Edit" : "Create"} Event</h2>
      <form onSubmit={handleSubmit}>
        <label>Title</label>
        <br />
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Description</label>
        <br />
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Date</label>
        <br />
        <input
          name="date"
          type="date"
          value={form.date}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit">{id ? "Update" : "Create"}</button>
      </form>
    </div>
  );
}
