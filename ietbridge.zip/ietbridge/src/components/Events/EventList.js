import React, { useEffect, useState } from "react";
import api from "../../services/api";
import { Link } from "react-router-dom";

export default function EventList() {
  const [events, setEvents] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/events")
      .then((res) => setEvents(res.data))
      .catch(() => setError("Failed to load events"));
  }, []);

  return (
    <div>
      <h2>Events</h2>
      <Link
        to="/events/rsvp"
        style={{ marginBottom: 10, display: "inline-block" }}
      >
        RSVP for Event (Alumni)
      </Link>
      <Link
        to="/events/manage"
        style={{ marginLeft: 20, display: "inline-block" }}
      >
        Manage Events (Admin)
      </Link>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <ul>
        {events.map((ev) => (
          <li key={ev.id}>
            {ev.title} - {new Date(ev.date).toLocaleDateString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
