import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import { Fade, Slide } from "react-awesome-reveal";

export default function CoursesPage() {
  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#FCF9F8",
        paddingTop: "60px",
        paddingBottom: "60px",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        color: "#333333",
      }}
    >
      <Container style={{ maxWidth: 960 }}>
        {/* Page Title */}
        <Slide direction="down" triggerOnce>
          <h1
            style={{
              color: "#16697A",
              fontWeight: 900,
              fontSize: "2.2rem",
              marginBottom: "28px",
              textAlign: "center",
            }}
          >
            Courses Offered at IET Pune
          </h1>
        </Slide>

        {/* Intro Paragraph */}
        <Fade cascade damping={0.2} triggerOnce>
          <p
            style={{
              fontSize: "1.12rem",
              lineHeight: 1.65,
              maxWidth: 800,
              margin: "0 auto 48px auto",
              textAlign: "center",
              color: "#555555",
            }}
          >
            At the Institute of Emerging Technologies, Pune, we provide
            carefully curated courses tailored to empower you with the latest IT
            knowledge and hands-on skills. Our programs are designed for
            graduates and professionals eager to grow in the tech industry.
          </p>
        </Fade>

        {/* PG-DAC Course Card */}
        <Fade triggerOnce>
          <Card
            style={{
              borderRadius: 14,
              marginBottom: "40px",
              boxShadow: "0 6px 18px rgba(22, 105, 122, 0.12)",
            }}
          >
            <Card.Body>
              <h2
                style={{
                  color: "#16697A",
                  fontWeight: 800,
                  fontSize: "1.6rem",
                  marginBottom: "18px",
                }}
              >
                Post Graduate Diploma in Advanced Computing (PG-DAC)
              </h2>
              <ul style={{ lineHeight: 1.55, color: "#444444" }}>
                <li>
                  <strong>Duration:</strong> 6 months (Full-time, intensive
                  sessions)
                </li>
                <li>
                  <strong>Eligibility:</strong> Engineering or Science
                  graduates, MCA/MCS/MCM
                </li>
                <li>
                  <strong>Curriculum Highlights:</strong>
                  <ul>
                    <li>Operating Systems & Networking</li>
                    <li>Java Object-Oriented Programming</li>
                    <li>
                      Web Technologies (JavaScript, HTML, CSS, React basics)
                    </li>
                    <li>Software Engineering, Project Management</li>
                    <li>Database Technologies & Data Structures</li>
                    <li>
                      Software Testing, Cloud Computing, Aptitude & Soft Skills
                    </li>
                    <li>
                      Final Project: Team-based real-world software development
                    </li>
                  </ul>
                </li>
                <li>
                  <strong>Placement Support:</strong> Dedicated interview
                  training and placement assistance
                </li>
              </ul>
            </Card.Body>
          </Card>
        </Fade>

        {/* Pre-DAC Course Card */}
        <Fade triggerOnce>
          <Card
            style={{
              borderRadius: 14,
              marginBottom: "40px",
              boxShadow: "0 6px 18px rgba(255, 111, 97, 0.15)",
              border: "1.8px solid #FF6F61",
            }}
          >
            <Card.Body>
              <h2
                style={{
                  color: "#FF6F61",
                  fontWeight: 800,
                  fontSize: "1.6rem",
                  marginBottom: "18px",
                }}
              >
                Pre-DAC Course (PG-DAC Preparation)
              </h2>
              <ul style={{ lineHeight: 1.55, color: "#555555" }}>
                <li>
                  <strong>Who Should Attend:</strong> Candidates preparing for
                  C-DAC PG-DAC entrance and foundational knowledge builders
                </li>
                <li>
                  <strong>Topics Covered:</strong> C Programming, Data
                  Structures, Operating Systems, Aptitude, Analytical Reasoning,
                  Spoken English, Communication Skills
                </li>
                <li>
                  <strong>Duration:</strong> 4–8 weeks (Flexible classroom and
                  online options)
                </li>
                <li>
                  <strong>Benefits:</strong> High entrance success rate with
                  strong programming foundation
                </li>
              </ul>
            </Card.Body>
          </Card>
        </Fade>

        {/* Why Choose Us Section */}
        <Slide direction="up" triggerOnce>
          <h2
            style={{
              color: "#16697A",
              fontWeight: 800,
              fontSize: "1.6rem",
              marginBottom: "28px",
              textAlign: "center",
              marginTop: "50px",
            }}
          >
            Why Choose IET Pune?
          </h2>
          <Row>
            <Col md={4}>
              <Card
                style={{
                  backgroundColor: "#FAF7F2",
                  borderRadius: 14,
                  border: "none",
                  boxShadow: "0 4px 12px rgba(22, 105, 122, 0.08)",
                  marginBottom: 24,
                }}
              >
                <Card.Body className="text-center">
                  <div
                    style={{
                      fontSize: "2.8rem",
                      marginBottom: "12px",
                      color: "#16697A",
                    }}
                    aria-hidden="true"
                  >
                    🎓
                  </div>
                  <Card.Title
                    as="h3"
                    style={{
                      fontWeight: 700,
                      color: "#16697A",
                      fontSize: "1.25rem",
                    }}
                  >
                    Industry Faculty
                  </Card.Title>
                  <Card.Text style={{ color: "#555555" }}>
                    Learn from active IT professionals with vast real-world
                    experience.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card
                style={{
                  backgroundColor: "#FFF6F5",
                  borderRadius: 14,
                  border: "none",
                  boxShadow: "0 4px 12px rgba(255, 111, 97, 0.15)",
                  marginBottom: 24,
                }}
              >
                <Card.Body className="text-center">
                  <div
                    style={{
                      fontSize: "2.8rem",
                      marginBottom: "12px",
                      color: "#FF6F61",
                    }}
                    aria-hidden="true"
                  >
                    🛠️
                  </div>
                  <Card.Title
                    as="h3"
                    style={{
                      fontWeight: 700,
                      color: "#FF6F61",
                      fontSize: "1.25rem",
                    }}
                  >
                    Hands-on Learning
                  </Card.Title>
                  <Card.Text style={{ color: "#555555" }}>
                    Practical projects and lab sessions deepen your
                    understanding.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card
                style={{
                  backgroundColor: "#F7F6F5",
                  borderRadius: 14,
                  border: "none",
                  boxShadow: "0 4px 12px rgba(22, 105, 122, 0.06)",
                  marginBottom: 24,
                }}
              >
                <Card.Body className="text-center">
                  <div
                    style={{
                      fontSize: "2.8rem",
                      marginBottom: "12px",
                      color: "#16697A",
                    }}
                    aria-hidden="true"
                  >
                    🤝
                  </div>
                  <Card.Title
                    as="h3"
                    style={{
                      fontWeight: 700,
                      color: "#16697A",
                      fontSize: "1.25rem",
                    }}
                  >
                    Strong Placements
                  </Card.Title>
                  <Card.Text style={{ color: "#555555" }}>
                    Dedicated career support, interview preparation, and
                    networking.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Slide>
      </Container>
    </div>
  );
}
