import React, { useState, useEffect } from "react";
import api from "../../services/api";
import { useNavigate, useParams } from "react-router-dom";

export default function AnnouncementForm() {
  const [form, setForm] = useState({
    title: "",
    content: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      api
        .get(`/announcements/${id}`)
        .then((res) =>
          setForm({
            title: res.data.title || "",
            content: res.data.content || "",
          })
        )
        .catch(() => setError("Failed to load announcement"));
    }
  }, [id]);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      if (id) {
        await api.put(`/announcements/${id}`, form);
      } else {
        await api.post("/announcements", form);
      }
      navigate("/announcements/manage");
    } catch {
      setError("Failed to save announcement");
    }
  };

  return (
    <div style={{ maxWidth: 500, margin: "auto" }}>
      <h2>{id ? "Edit" : "Create"} Announcement</h2>
      <form onSubmit={handleSubmit}>
        <label>Title</label>
        <br />
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Content</label>
        <br />
        <textarea
          name="content"
          value={form.content}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10, height: 150 }}
        />

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit">{id ? "Update" : "Create"}</button>
      </form>
    </div>
  );
}
