import React, { useEffect, useState } from "react";
import api from "../../services/api";
import { Link } from "react-router-dom";

export default function AnnouncementList() {
  const [announcements, setAnnouncements] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/announcements")
      .then((res) => setAnnouncements(res.data))
      .catch(() => setError("Failed to load announcements"));
  }, []);

  return (
    <div>
      <h2>Announcements</h2>
      <Link
        to="/announcements/create"
        style={{ marginBottom: 10, display: "inline-block" }}
      >
        Create Announcement (Admin only)
      </Link>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <ul>
        {announcements.map((a) => (
          <li key={a.id}>
            <strong>{a.title}</strong>: {a.content}
          </li>
        ))}
      </ul>
    </div>
  );
}
