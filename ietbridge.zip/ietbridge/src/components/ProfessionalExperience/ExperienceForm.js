import React, { useState, useEffect } from "react";
import api from "../../services/api";
import { useNavigate, useParams } from "react-router-dom";

export default function ExperienceForm() {
  const [form, setForm] = useState({
    company: "",
    title: "",
    industry: "",
    startDate: "",
    endDate: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      api
        .get(`/professional-experience/${id}`)
        .then((res) =>
          setForm({
            company: res.data.company || "",
            title: res.data.title || "",
            industry: res.data.industry || "",
            startDate: res.data.startDate?.substring(0, 10) || "",
            endDate: res.data.endDate?.substring(0, 10) || "",
          })
        )
        .catch(() => setError("Failed to load experience"));
    }
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      if (id) {
        await api.put(`/professional-experience/${id}`, form);
      } else {
        await api.post("/professional-experience", form);
      }
      navigate("/professional-experience");
    } catch {
      setError("Failed to save experience");
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto" }}>
      <h2>{id ? "Edit" : "Add"} Professional Experience</h2>
      <form onSubmit={handleSubmit}>
        <label>Company</label>
        <br />
        <input
          name="company"
          value={form.company}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Title</label>
        <br />
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Industry</label>
        <br />
        <input
          name="industry"
          value={form.industry}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>Start Date</label>
        <br />
        <input
          name="startDate"
          type="date"
          value={form.startDate}
          onChange={handleChange}
          required
          style={{ width: "100%", marginBottom: 10 }}
        />

        <label>End Date</label>
        <br />
        <input
          name="endDate"
          type="date"
          value={form.endDate}
          onChange={handleChange}
          style={{ width: "100%", marginBottom: 10 }}
        />

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit">{id ? "Update" : "Add"}</button>
      </form>
    </div>
  );
}
