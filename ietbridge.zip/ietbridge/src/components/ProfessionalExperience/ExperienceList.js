import React, { useEffect, useState } from "react";
import api from "../../services/api";
import { Link } from "react-router-dom";

export default function ExperienceList() {
  const [experiences, setExperiences] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/professional-experience")
      .then((res) => setExperiences(res.data))
      .catch(() => setError("Failed to load professional experiences"));
  }, []);

  return (
    <div>
      <h2>Professional Experiences</h2>
      <Link
        to="/professional-experience/new"
        style={{ marginBottom: 10, display: "inline-block" }}
      >
        Add New Experience
      </Link>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <ul>
        {experiences.map((exp) => (
          <li key={exp.id}>
            {exp.title} at {exp.company} ({exp.startDate?.substring(0, 10)} -{" "}
            {exp.endDate?.substring(0, 10) || "Present"}){" "}
            <Link to={`/professional-experience/edit/${exp.id}`}>Edit</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
