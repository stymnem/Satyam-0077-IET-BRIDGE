import React from "react";
import { NavLink, Link } from "react-router-dom";
import { useAuth } from "./contexts/AuthContext"; // Adjust path

export default function Navbar() {
  const { user, logout } = useAuth();

  // Style function for active/inactive links
  const linkStyle = (isActive) => ({
    color: isActive ? "#FF577F" : "#232946", // coral for active, dark gray-blue for inactive
    fontWeight: 700,
    letterSpacing: "0.5px",
    transition: "color 0.2s ease",
  });

  return (
    <nav
      className="navbar navbar-expand-lg navbar-light"
      style={{
        background: "linear-gradient(90deg, #5C27FE 60%, #2FE1F9 100%)",
        boxShadow: "0 2px 8px 0 rgba(91,39,254,0.07)",
      }}
    >
      <div className="container">
        {/* Brand */}
        <Link
          to="/"
          className="navbar-brand fw-bold"
          style={{ color: "#fff", fontSize: "1.4rem", letterSpacing: "1px" }}
        >
          IETBRIDGE
        </Link>

        {/* Hamburger Toggle Button */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNavAltMarkup"
          aria-controls="navbarNavAltMarkup"
          aria-expanded="false"
          aria-label="Toggle navigation"
          style={{ borderColor: "rgba(255, 255, 255, 0.55)" }}
        >
          <span className="navbar-toggler-icon" />
        </button>

        {/* Collapsible Nav Links */}
        <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div className="navbar-nav ms-auto align-items-center">
            {/* Common Public Links */}
            <NavLink
              to="/"
              end
              className="nav-link"
              style={({ isActive }) => linkStyle(isActive)}
            >
              Home
            </NavLink>
            <NavLink
              to="/about"
              className="nav-link"
              style={({ isActive }) => linkStyle(isActive)}
            >
              About
            </NavLink>
            <NavLink
              to="/courses"
              className="nav-link"
              style={({ isActive }) => linkStyle(isActive)}
            >
              Courses
            </NavLink>
            <NavLink
              to="/placements"
              className="nav-link"
              style={({ isActive }) => linkStyle(isActive)}
            >
              Placements
            </NavLink>
            <NavLink
              to="/contact"
              className="nav-link"
              style={({ isActive }) => linkStyle(isActive)}
            >
              Contact
            </NavLink>

            {/* Authentication Links */}
            {!user && (
              <NavLink
                to="/login"
                className="nav-link"
                style={({ isActive }) => linkStyle(isActive)}
              >
                Login
              </NavLink>
            )}

            {/* Role-based links: Alumni */}
            {user && user.role === "Alumni" && (
              <>
                <NavLink
                  to="/profile"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Profile
                </NavLink>
                <NavLink
                  to="/education"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Education
                </NavLink>
                <NavLink
                  to="/professional-experience"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Professional Experience
                </NavLink>
                <NavLink
                  to="/jobs"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Job Board
                </NavLink>
                <NavLink
                  to="/events"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Events
                </NavLink>
                <NavLink
                  to="/announcements"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Announcements
                </NavLink>
                <NavLink
                  to="/messages"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Messages
                </NavLink>
              </>
            )}

            {/* Role-based links: Admin */}
            {user && user.role === "Admin" && (
              <>
                <NavLink
                  to="/events/manage"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Manage Events
                </NavLink>
                <NavLink
                  to="/announcements/manage"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  Manage Announcements
                </NavLink>
                <NavLink
                  to="/rsvps/all"
                  className="nav-link"
                  style={({ isActive }) => linkStyle(isActive)}
                >
                  View All RSVPs
                </NavLink>
              </>
            )}

            {/* Logout Button */}
            {user && (
              <button
                onClick={logout}
                className="nav-link btn btn-link"
                style={{
                  color: "#232946",
                  fontWeight: 700,
                  textDecoration: "none",
                  cursor: "pointer",
                  paddingLeft: 0,
                  marginLeft: "0.5rem",
                }}
              >
                Logout
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
