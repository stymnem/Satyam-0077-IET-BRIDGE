﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [Authorize(Roles = "Admin, Alumni")]
    [ApiController]
    [Route("api/announcements")]

    public class AnnouncementsController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public AnnouncementsController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var announcements = await _context.Announcements.ToListAsync();
            return Ok(announcements);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(AnnouncementDto dto)
        {
            var adminId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var announcement = new Announcement
            {
                Title = dto.Title,
                Message = dto.Message,
                CreatedBy = adminId,
                CreatedAt = DateTime.UtcNow
            };

            _context.Announcements.Add(announcement);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAll), new { id = announcement.Id }, announcement);
        }
    }
}

