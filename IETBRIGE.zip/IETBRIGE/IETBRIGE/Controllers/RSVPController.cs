﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [ApiController]
    [Route("api/rsvps")]
    [Authorize(Roles = "Alumni")]
    public class RSVPsController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public RSVPsController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> RSVP(RSVPDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

            if (await _context.RSVPs.AnyAsync(r => r.EventId == dto.EventId && r.UserId == userId))
                return BadRequest("Already RSVPed to this event");

            _context.RSVPs.Add(new RSVP
            {
                EventId = dto.EventId,
                UserId = userId,
                RSVPDate = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();
            return Ok("RSVP successful");
        }

        [HttpGet("mine")]
        public async Task<IActionResult> MyRSVPs()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var rsvps = await _context.RSVPs
                .Where(r => r.UserId == userId)
                .Include(r => r.Event)
                .ToListAsync();

            return Ok(rsvps);
        }
    }
}

