﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [ApiController]
    [Route("api/messages")]
    [Authorize(Roles = "Alumni")]
    public class MessagesController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public MessagesController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        [HttpGet("inbox")]
        public async Task<IActionResult> Inbox()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

            var messages = await _context.Messages
                .Where(m => m.ReceiverId == userId)
                .Include(m => m.Sender)
                .ToListAsync();

            return Ok(messages);
        }

        [HttpGet("sent")]
        public async Task<IActionResult> Sent()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var messages = await _context.Messages
                .Where(m => m.SenderId == userId)
                .Include(m => m.Receiver)
                .ToListAsync();

            return Ok(messages);
        }

        [HttpPost]
        public async Task<IActionResult> Send(MessageDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var receiverExists = await _context.Users.AnyAsync(u => u.Id == dto.ReceiverId);
            if (!receiverExists) return BadRequest("Receiver does not exist");

            var message = new Message
            {
                SenderId = userId,
                ReceiverId = dto.ReceiverId,
                Content = dto.Content,
                SentAt = DateTime.UtcNow,
                IsRead = false
            };

            _context.Messages.Add(message);
            await _context.SaveChangesAsync();
            return Ok(message);
        }

        [HttpPut("{id}/read")]
        public async Task<IActionResult> MarkAsRead(int id)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

            var message = await _context.Messages.SingleOrDefaultAsync(m => m.Id == id && m.ReceiverId == userId);
            if (message == null) return NotFound();

            message.IsRead = true;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var message = await _context.Messages.SingleOrDefaultAsync(m => m.Id == id && (m.SenderId == userId || m.ReceiverId == userId));
            if (message == null) return NotFound();

            _context.Messages.Remove(message);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}

