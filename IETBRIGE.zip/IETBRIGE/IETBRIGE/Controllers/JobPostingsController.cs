﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [ApiController]
    [Route("api/jobpostings")]
    public class JobPostingsController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public JobPostingsController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var jobs = await _context.JobPostings.ToListAsync();
            return Ok(jobs);
        }

        [HttpPost]
        [Authorize(Roles = "Alumni")]
        public async Task<IActionResult> Create(JobPostingDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var job = new JobPosting
            {
                UserId = userId,
                Title = dto.Title,
                Company = dto.Company,
                Location = dto.Location,
                Description = dto.Description,
                PostedAt = DateTime.UtcNow
            };

            _context.JobPostings.Add(job);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAll), new { id = job.Id }, job);
        }
    }
}
