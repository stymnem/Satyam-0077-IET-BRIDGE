﻿using IETBRIGE.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace IETBRIGE.Data
{
    public class AlumniManagementDbContext : DbContext
    {
        public AlumniManagementDbContext(DbContextOptions<AlumniManagementDbContext> options)
            : base(options) { }

        public DbSet<User> Users => Set<User>();
        public DbSet<Education> Educations => Set<Education>();
        public DbSet<ProfessionalExperience> ProfessionalExperiences => Set<ProfessionalExperience>();
        public DbSet<JobPosting> JobPostings => Set<JobPosting>();
        public DbSet<Event> Events => Set<Event>();
        public DbSet<RSVP> RSVPs => Set<RSVP>();
        public DbSet<Announcement> Announcements => Set<Announcement>();
        public DbSet<Message> Messages => Set<Message>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();
            modelBuilder.Entity<Message>()
                .HasOne(m => m.Sender)
                .WithMany(u => u.MessagesSent)
                .HasForeignKey(m => m.SenderId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<Message>()
                .HasOne(m => m.Receiver)
                .WithMany(u => u.MessagesReceived)
                .HasForeignKey(m => m.ReceiverId)
                .OnDelete(DeleteBehavior.SetNull);
            modelBuilder.Entity<JobPosting>()
                .HasOne(j => j.User)
                .WithMany(u => u.JobPostings)
                .HasForeignKey(j => j.UserId)
                .OnDelete(DeleteBehavior.SetNull);
            modelBuilder.Entity<Event>()
                .HasOne(e => e.Creator)
                .WithMany(u => u.EventsCreated)
                .HasForeignKey(e => e.CreatedBy)
                .OnDelete(DeleteBehavior.SetNull);
            modelBuilder.Entity<Announcement>()
                .HasOne(a => a.Creator)
                .WithMany(u => u.AnnouncementsCreated)
                .HasForeignKey(a => a.CreatedBy)
                .OnDelete(DeleteBehavior.SetNull);
            modelBuilder.Entity<RSVP>()
                .HasOne(r => r.Event)
                .WithMany(e => e.RSVPs)
                .HasForeignKey(r => r.EventId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<RSVP>()
                .HasOne(r => r.User)
                .WithMany(u => u.RSVPs)
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<Education>()
                .ToTable("Education")
                 .HasOne(e => e.User)
                 .WithMany(u => u.Educations)
                 .HasForeignKey(e => e.UserId)
                 .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<ProfessionalExperience>()
                .ToTable("ProfessionalExperience")
                .HasOne(p => p.User)
                .WithMany(u => u.ProfessionalExperiences)
                .HasForeignKey(p => p.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}

