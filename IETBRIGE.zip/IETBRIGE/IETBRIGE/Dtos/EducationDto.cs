﻿using System.ComponentModel.DataAnnotations;

namespace IETBRIGE.Dtos
{
    public class EducationDto
    {
        [Required]
        public int? Id { get; set; }

        [Required]
        public string? Degree { get; set; }

        [Required]
        public string? Branch { get; set; }

        [Required]
        public string? Institute { get; set; }

        [Range(1900, 2100)]
        public int? GraduationYear { get; set; }
    }
}
