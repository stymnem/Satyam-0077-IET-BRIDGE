﻿namespace IETBRIGE.Dtos
{
    public class JobPostingDto
    {
        public int? Id { get; set; }
        public string? Title { get; set; }
        public string? Company { get; set; }
        public string? Location { get; set; }
        public string? Description { get; set; }
    }
}
