﻿using System.ComponentModel.DataAnnotations;

namespace IETBRIGE.Dtos
{
    public class RegisterDto
    {
        public string FullName { get; set; } = null!;

        [EmailAddress, Required]
        public string Email { get; set; } = null!;

        [MinLength(6), Required]
        public string Password { get; set; } = null!;
        public string Role { get; set; } = null!;
    }

}
