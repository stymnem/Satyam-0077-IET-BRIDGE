﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace IETBRIGE.Models
{
    public class User
    {
        public int Id { get; set; }
        public string FullName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;
        public string Role { get; set; } = null!;  // "Admin" or "Alumni"
        public string? Phone { get; set; }
        public string? ProfilePic { get; set; }
        public string? Bio { get; set; }
        public int? BatchYear { get; set; }
        public DateTime CreatedAt { get; set; }

        public ICollection<Education> Educations { get; set; } = new List<Education>();
        public ICollection<ProfessionalExperience> ProfessionalExperiences { get; set; } = new List<ProfessionalExperience>();
        public ICollection<JobPosting> JobPostings { get; set; } = new List<JobPosting>();
        public ICollection<Event> EventsCreated { get; set; } = new List<Event>();
        public ICollection<RSVP> RSVPs { get; set; } = new List<RSVP>();
        public ICollection<Announcement> AnnouncementsCreated { get; set; } = new List<Announcement>();
        public ICollection<Message> MessagesSent { get; set; } = new List<Message>();
        public ICollection<Message> MessagesReceived { get; set; } = new List<Message>();
    }
}
