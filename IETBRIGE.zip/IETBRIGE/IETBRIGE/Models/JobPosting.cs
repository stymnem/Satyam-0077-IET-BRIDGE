﻿using System;
using System.Collections.Generic;

namespace IETBRIGE.Models
{
    public class JobPosting
    {
        public int Id { get; set; }
        public int? UserId { get; set; }
        public string? Title { get; set; }
        public string? Company { get; set; }
        public string? Location { get; set; }
        public string? Description { get; set; }
        public DateTime PostedAt { get; set; }

        public User? User { get; set; }
    }
}
